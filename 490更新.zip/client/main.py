# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


# 发送端
import socket
import os
from struct import pack
from struct import unpack
import time
from tqdm import tqdm
import zipfile
import sys
import glob

def get_host_ip():
    """
    查询本机ip地址
    :return:
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    finally:
        s.close()
    return ip


# 压缩文件
class zip:
    def get_zip(self, files, zip_name):
        zp = zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED)
        for idx,file in enumerate(files):
            zp.write(file,str(idx)+'.jpg')#,'./'+os.path.split(file)[1]
        zp.close()
        print('压缩完成')


def send_file(file_name, file_socket: socket.socket):
    try:
        f = open(file_name, 'rb')
        size = os.path.getsize(file_name)
        if size < 1024:
            read_size = 1024
        elif size < 1024 * 1024 and size >= 1024:
            read_size = 1024 * 1024
        else:
            read_size = 500 * 1024 * 1024
        file_socket.send(pack('q', size))
        del size
        file_socket.recv(1024)
        while True:
            data = f.read(read_size)
            if not data:
                break
            file_socket.send(data)
        f.close()
    except FileNotFoundError:
        print(f'没有找到{file_name}')


def download(file_name, file_socket: socket.socket):
    file_size = unpack('q', file_socket.recv(1024))[0]
    if file_size < 1024:
        print(f'文件大小：{file_size} B')
    elif file_size < 1024 * 1024 and file_size >= 1024:
        print(f'文件大小：{file_size / 1024} KB')
    else:
        print(f'文件大小：{file_size / (1024 * 1024)} MB')
    f = open(file_name, 'wb')
    print('开始传输...')
    download_size = 2048
    file_socket.send('开始传输'.encode('gbk'))
    start = time.time()
    for i in tqdm(range(int(file_size / download_size) + 1)):
        data = file_socket.recv(download_size)
        f.write(data)
    end = time.time()
    f.close()
    print('传输完成！')
    print(f'大约耗时{end - start}秒')


if __name__ == '__main__':
    ip = ""
    judge = False
    #for root, dirs, files in os.walk(os.path.abspath('.')):
    for files in [os.listdir(os.path.abspath('.'))]:
        for file in files:
            if "ipconfig.xml" in file:
                judge = True
                break
    if judge == False:
        print("没有发现配置文件！请手动输入server端ip地址")
    else:
        f = open("ipconfig.xml")
        ip = f.readline().split("\n")[0]
        f.close()
    try:
        file_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        file_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, True)
        if ip == "":
            ip = str(input('请输入接收端IP：'))
        port = int(input('请输入接收端端口号：'))
        file_socket.connect((ip, port))
        print('连接成功，准备开始传输。。。')
        path = r'%s' % (input('请输入文件所在文件夹：'))
        file_socket.recv(1024).decode('gbk')
        for root, dirs, files in os.walk(path):
            # z = zip()
            # # 压缩包路径及名字
            # zip_name = "zipfile.zip"
            # zip_file = path + '\\' + zip_name
            # path_file = []
            # for file in files:
            #     path_file.append(path + "\\" + file)
            # z.get_zip(path_file, zip_file)
            # file_socket.send(zip_name.encode('gbk'))
            # send_file(zip_file, file_socket)
            # os.remove(zip_file)
            zipFilePath = os.path.join(sys.path[0], "test.zip")
            zipFile = zipfile.ZipFile(zipFilePath, "w", zipfile.ZIP_DEFLATED)
            fs=glob.glob(os.path.join(path, '*.jpg'))
            for idx, file in enumerate(fs):
                zipFile.write(file, str(idx) + '.jpg')
            zipFile.close()
            while zipfile.is_zipfile(zipFilePath) == False:
                time.sleep(1)
            file_socket.send("test.zip".encode('gbk'))
            send_file(zipFilePath, file_socket)
            os.remove(zipFilePath)
        try:
            file_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            file_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, True)
            file_socket_port = 8080
            # file_socket_port = int(input('请输入端口号：'))
            file_socket.bind(('', file_socket_port))
            print('成功启动，等待服务器回传。。。')
            file_socket.listen(128)
            f_socket, f_addr = file_socket.accept()
            print(f'建立连接{f_addr}')
            f_socket.send('请输入文件名'.encode('gbk'))
            file_name = f_socket.recv(1024)
            print(file_name)
            download(file_name.decode('gbk'), f_socket)
            f_socket.close()
            file_socket.close()
        except ConnectionResetError:
            print('发送端已断开连接')
        except UnicodeDecodeError:
            print('文件编码错误，请检查文件格式是否正确')
    except ConnectionResetError:
        print('接收端断开连接')
# See PyCharm help at https://www.jetbrains.com/help/pycharm/
